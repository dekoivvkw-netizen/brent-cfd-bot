#!/usr/bin/env python3
"""
Brent CFD Signal Bot v3 — preciso e automatico
==============================================
Conferme richieste prima di COMPRA/VENDI:
  1. Trend 1 ora allineato (EMA 20/50)
  2. Trend 15 minuti allineato
  3. RSI nella fascia, non estremo
  4. ATR sopra la mediana recente (niente mercato morto)
  5. Stesso segnale sulle ultime 2 candele da 15 minuti

Non apre ordini. Non è un consiglio finanziario.

Uso:
  python brent_bot.py
  python brent_bot.py --offset 3.35
  python brent_bot.py --loop --interval 15
  python brent_bot.py --backtest

Email solo se il segnale cambia (password fuori dal file):
  export BRENT_EMAIL=lerbi.demoreti@hotmail.com
  export BRENT_EMAIL_PASSWORD=app_password
"""

from __future__ import annotations

import argparse
import os
import smtplib
import ssl
import time
import warnings
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import numpy as np
import pandas as pd
import yfinance as yf

warnings.filterwarnings("ignore")

SYMBOL = "BZ=F"
OFFSET = 3.35
EMAIL_TO = os.environ.get("BRENT_EMAIL", "lerbi.demoreti@hotmail.com")
EMAIL_FROM = os.environ.get("BRENT_EMAIL_FROM", EMAIL_TO)
EMAIL_PASSWORD = os.environ.get("BRENT_EMAIL_PASSWORD", "")
SMTP_SERVER = os.environ.get("BRENT_SMTP", "smtp-mail.outlook.com")
SMTP_PORT = int(os.environ.get("BRENT_SMTP_PORT", "587"))
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "brent_signal_log.txt")

MODES = {
    "precise": {"rsi_buy": (42, 62), "rsi_sell": (38, 58), "sl": 1.8, "tp": 2.6, "confirm": 2},
    "conservative": {"rsi_buy": (42, 55), "rsi_sell": (45, 58), "sl": 2.0, "tp": 3.0, "confirm": 2},
    "balanced": {"rsi_buy": (40, 65), "rsi_sell": (35, 60), "sl": 1.6, "tp": 2.2, "confirm": 1},
}


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    up = d.clip(lower=0).rolling(n).mean()
    down = (-d.clip(upper=0)).rolling(n).mean()
    return 100 - 100 / (1 + up / down.replace(0, np.nan))


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    prev = df["Close"].shift(1)
    tr = pd.concat([
        df["High"] - df["Low"],
        (df["High"] - prev).abs(),
        (df["Low"] - prev).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(n).mean()


def fetch(period: str, interval: str) -> pd.DataFrame:
    df = yf.Ticker(SYMBOL).history(period=period, interval=interval)
    if df.empty:
        raise RuntimeError("Nessun dato Brent")
    out = df[["Open", "High", "Low", "Close", "Volume"]].dropna().copy()
    out["EMA20"] = ema(out["Close"], 20)
    out["EMA50"] = ema(out["Close"], 50)
    out["RSI"] = rsi(out["Close"])
    out["ATR"] = atr(out)
    out["ATR_MED"] = out["ATR"].rolling(50).median()
    out["Trend"] = np.where(
        (out["EMA20"] > out["EMA50"]) & (out["Close"] > out["EMA20"]), "BULLISH",
        np.where((out["EMA20"] < out["EMA50"]) & (out["Close"] < out["EMA20"]), "BEARISH", "SIDEWAYS"),
    )
    return out.dropna()


def raw_signal(row: pd.Series, mode: str) -> str:
    cfg = MODES[mode]
    r = float(row["RSI"])
    if row["Trend"] == "BULLISH" and cfg["rsi_buy"][0] <= r <= cfg["rsi_buy"][1]:
        return "COMPRA"
    if row["Trend"] == "BEARISH" and cfg["rsi_sell"][0] <= r <= cfg["rsi_sell"][1]:
        return "VENDI"
    return "NEUTRO"


def decide(fast: pd.DataFrame, slow: pd.DataFrame, mode: str) -> tuple[str, str, pd.Series]:
    cfg = MODES[mode]
    last = fast.iloc[-1]
    hour = slow.iloc[-1]
    votes = [raw_signal(fast.iloc[i], mode) for i in range(-cfg["confirm"], 0)]
    agreed = len(set(votes)) == 1 and votes[0] != "NEUTRO"
    volatile = float(last["ATR"]) >= float(last["ATR_MED"]) * 0.85
    aligned = (votes[0] == "COMPRA" and hour["Trend"] == "BULLISH") or (
        votes[0] == "VENDI" and hour["Trend"] == "BEARISH"
    )
    if agreed and volatile and aligned:
        reason = (
            f"15m {votes[0]} x{cfg['confirm']} candele, 1h {hour['Trend']}, "
            f"RSI {float(last['RSI']):.1f}, ATR ok"
        )
        return votes[0], reason, last
    why = []
    if not agreed:
        why.append("15m non confermato")
    if not volatile:
        why.append("volatilità bassa")
    if votes[0] != "NEUTRO" and not aligned:
        why.append(f"1h è {hour['Trend']}, non allineato")
    if not why:
        why.append("nessun trend pulito")
    return "NEUTRO", "; ".join(why), last


def levels(row: pd.Series, side: str, mode: str) -> tuple[float, float]:
    cfg = MODES[mode]
    p, a = float(row["Close"]), float(row["ATR"])
    if side == "COMPRA":
        return p - cfg["sl"] * a, p + cfg["tp"] * a
    return p + cfg["sl"] * a, p - cfg["tp"] * a


def shift(df: pd.DataFrame, offset: float) -> pd.DataFrame:
    if not offset:
        return df
    out = df.copy()
    for c in ("Open", "High", "Low", "Close", "EMA20", "EMA50"):
        out[c] = out[c] + offset
    return out


def send_email(subject: str, body: str) -> bool:
    if not EMAIL_PASSWORD:
        print("Email saltata: manca BRENT_EMAIL_PASSWORD")
        return False
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))
    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=30) as server:
        server.ehlo()
        server.starttls(context=ssl.create_default_context())
        server.login(EMAIL_FROM, EMAIL_PASSWORD)
        server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())
    print(f"Email inviata a {EMAIL_TO}")
    return True


def log(side: str, price: float, reason: str) -> None:
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat()} | {side} | {price:.3f} | {reason}\n")


def once(offset: float, mode: str, mail: bool) -> str:
    fast = shift(fetch("10d", "15m"), offset)
    slow = shift(fetch("60d", "1h"), offset)
    side, reason, last = decide(fast, slow, mode)
    price = float(last["Close"])
    print("=" * 60)
    print(f"BRENT PRECISO  {datetime.now():%Y-%m-%d %H:%M}  mode={mode}")
    print(f"Prezzo {price:.3f}   RSI {float(last['RSI']):.1f}   15m {last['Trend']}   ATR {float(last['ATR']):.3f}")
    print(f"SEGNALE: {side}")
    print(reason)
    if side != "NEUTRO":
        sl, tp = levels(last, side, mode)
        print(f"Stop {sl:.2f}   Target {tp:.2f}")
        if side == "COMPRA":
            print("Short ~106.29: contro il segnale, valuta chiusura.")
        else:
            print("Short ~106.29: allineato. Lo stop resta tuo.")
    print("=" * 60)
    log(side, price, reason)
    if mail and side != "NEUTRO":
        body = f"{side}\nPrezzo {price:.2f}\n{reason}"
        send_email(f"BRENT {side} {price:.2f}", body)
    return side


def backtest(mode: str) -> None:
    df = fetch("2y", "1d")
    cfg = MODES[mode]
    cash, start, trades, pos = 10000.0, 10000.0, [], None
    for i in range(2, len(df)):
        prev, row = df.iloc[i - 1], df.iloc[i]
        side = raw_signal(prev, mode)
        if pos:
            hit = None
            if pos["side"] == "COMPRA":
                if row["Low"] <= pos["sl"]:
                    hit = pos["sl"]
                elif row["High"] >= pos["tp"]:
                    hit = pos["tp"]
                pnl = None if hit is None else (hit - pos["entry"]) * pos["size"]
            else:
                if row["High"] >= pos["sl"]:
                    hit = pos["sl"]
                elif row["Low"] <= pos["tp"]:
                    hit = pos["tp"]
                pnl = None if hit is None else (pos["entry"] - hit) * pos["size"]
            if hit is not None:
                cash += pnl
                trades.append(pnl)
                pos = None
        if pos is None and side != "NEUTRO" and float(prev["ATR"]) >= float(prev["ATR_MED"]) * 0.85:
            dist = cfg["sl"] * float(prev["ATR"])
            size = (cash * 0.01) / dist
            entry = float(row["Open"])
            if side == "COMPRA":
                pos = {"side": side, "entry": entry, "sl": entry - dist, "tp": entry + cfg["tp"] * float(prev["ATR"]), "size": size}
            else:
                pos = {"side": side, "entry": entry, "sl": entry + dist, "tp": entry - cfg["tp"] * float(prev["ATR"]), "size": size}
    wins = [t for t in trades if t > 0]
    print(f"{mode:13} trade {len(trades):3}  win {100*len(wins)/len(trades) if trades else 0:5.1f}%  "
          f"PnL {cash-start:+8.2f} $")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=list(MODES), default="precise")
    p.add_argument("--offset", type=float, default=OFFSET)
    p.add_argument("--loop", action="store_true")
    p.add_argument("--interval", type=int, default=15)
    p.add_argument("--backtest", action="store_true")
    p.add_argument("--test-email", action="store_true")
    args = p.parse_args()
    if args.test_email:
        send_email("Test Brent preciso", "Email ok.")
        return
    if args.backtest:
        for mode in MODES:
            backtest(mode)
        return
    side = once(args.offset, args.mode, mail=True)
    if not args.loop:
        return
    print(f"Automatico ogni {args.interval} minuti. Ctrl+C per fermare.")
    prev = side
    while True:
        time.sleep(max(1, args.interval) * 60)
        try:
            side = once(args.offset, args.mode, mail=False)
            if side != prev and side != "NEUTRO":
                once(args.offset, args.mode, mail=True)
            prev = side
        except Exception as exc:
            print(f"Errore: {exc}")
            time.sleep(20)


if __name__ == "__main__":
    main()
