#!/usr/bin/env python3
"""
Brent CFD - Backtest 2 anni (dati daily)
---------------------------------------
Simula la strategia su ~2 anni di dati giornalieri.
Include:
  - 3 modalità (conservative / balanced / aggressive)
  - Stop loss e take profit basati su ATR
  - Uscita anche su segnale opposto
  - Statistiche complete: winrate, profit factor, max drawdown, ecc.
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime
import ta
import warnings
warnings.filterwarnings("ignore")

SYMBOL = "BZ=F"
PERIOD = "2y"
INTERVAL = "1d"

EMA_FAST = 20
EMA_SLOW = 50
RSI_PERIOD = 14
BB_PERIOD = 20
ATR_PERIOD = 14

MODES = {
    "conservative": {
        "rsi_buy_max": 55, "rsi_sell_min": 45,
        "rsi_oversold": 25, "rsi_overbought": 75,
        "require_ema_cross": True,
        "sl_atr": 2.0, "tp_atr": 3.0,
        "description": "Pochi segnali, alta qualità"
    },
    "balanced": {
        "rsi_buy_max": 65, "rsi_sell_min": 35,
        "rsi_oversold": 30, "rsi_overbought": 70,
        "require_ema_cross": False,
        "sl_atr": 1.8, "tp_atr": 2.5,
        "description": "Equilibrio frequenza/qualità"
    },
    "aggressive": {
        "rsi_buy_max": 72, "rsi_sell_min": 28,
        "rsi_oversold": 35, "rsi_overbought": 65,
        "require_ema_cross": False,
        "sl_atr": 1.5, "tp_atr": 2.2,
        "description": "Più segnali, più rischio"
    }
}


def fetch_data():
    print("Scarico 2 anni di dati daily Brent (BZ=F)...")
    ticker = yf.Ticker(SYMBOL)
    df = ticker.history(period=PERIOD, interval=INTERVAL)
    if df.empty:
        raise ValueError("Nessun dato ricevuto")
    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df.dropna(inplace=True)
    print(f"  Periodo : {df.index[0].date()} → {df.index[-1].date()}")
    print(f"  Candele : {len(df)}")
    print(f"  Prezzo  : min {df['Close'].min():.2f}  max {df['Close'].max():.2f}  ultimo {df['Close'].iloc[-1]:.2f}")
    return df


def add_indicators(df):
    df["EMA_fast"] = ta.trend.ema_indicator(df["Close"], window=EMA_FAST)
    df["EMA_slow"] = ta.trend.ema_indicator(df["Close"], window=EMA_SLOW)
    df["RSI"] = ta.momentum.rsi(df["Close"], window=RSI_PERIOD)
    bb = ta.volatility.BollingerBands(df["Close"], window=BB_PERIOD, window_dev=2)
    df["BB_upper"] = bb.bollinger_hband()
    df["BB_lower"] = bb.bollinger_lband()
    df["ATR"] = ta.volatility.average_true_range(df["High"], df["Low"], df["Close"], window=ATR_PERIOD)
    df["Trend"] = np.where(
        (df["EMA_fast"] > df["EMA_slow"]) & (df["Close"] > df["EMA_fast"]), "BULLISH",
        np.where((df["EMA_fast"] < df["EMA_slow"]) & (df["Close"] < df["EMA_fast"]), "BEARISH", "SIDEWAYS")
    )
    return df.dropna()


def generate_signal(row, mode):
    cfg = MODES[mode]
    close, rsi = row["Close"], row["RSI"]
    ema_f, ema_s = row["EMA_fast"], row["EMA_slow"]
    bb_u, bb_l = row["BB_upper"], row["BB_lower"]
    trend = row["Trend"]

    buy = (trend == "BULLISH" and rsi < cfg["rsi_buy_max"] and rsi > 40 and close > ema_f)
    if cfg["require_ema_cross"]:
        buy = buy and (ema_f > ema_s)
    if buy:
        return "COMPRA"

    sell = (trend == "BEARISH" and rsi > cfg["rsi_sell_min"] and rsi < 60 and close < ema_f)
    if cfg["require_ema_cross"]:
        sell = sell and (ema_f < ema_s)
    if sell:
        return "VENDI"

    if rsi < cfg["rsi_oversold"] and close <= bb_l * 1.002:
        return "COMPRA"
    if rsi > cfg["rsi_overbought"] and close >= bb_u * 0.998:
        return "VENDI"
    return "NEUTRO"


def run_backtest(df, mode="balanced", initial_capital=10000.0, risk_pct=1.0):
    """
    Backtest realistico:
    - Entra al close della candela del segnale
    - Stop loss / Take profit basati su ATR
    - Uscita anche su segnale opposto
    - Size basata su rischio % del capitale
    """
    cfg = MODES[mode]
    capital = initial_capital
    equity_curve = [capital]
    trades = []
    position = None  # {"side", "entry", "sl", "tp", "size", "entry_idx"}

    for i in range(1, len(df)):
        row = df.iloc[i]
        prev = df.iloc[i-1]
        signal = generate_signal(prev, mode)  # segnale sulla candela precedente
        high, low, close = row["High"], row["Low"], row["Close"]
        atr = prev["ATR"]

        # 1. Gestione posizione aperta
        if position is not None:
            exit_price = None
            exit_reason = None

            if position["side"] == "COMPRA":
                if low <= position["sl"]:
                    exit_price = position["sl"]
                    exit_reason = "SL"
                elif high >= position["tp"]:
                    exit_price = position["tp"]
                    exit_reason = "TP"
                elif signal == "VENDI":
                    exit_price = close
                    exit_reason = "Segnale opposto"
            else:  # VENDI (short)
                if high >= position["sl"]:
                    exit_price = position["sl"]
                    exit_reason = "SL"
                elif low <= position["tp"]:
                    exit_price = position["tp"]
                    exit_reason = "TP"
                elif signal == "COMPRA":
                    exit_price = close
                    exit_reason = "Segnale opposto"

            if exit_price is not None:
                if position["side"] == "COMPRA":
                    pnl = (exit_price - position["entry"]) * position["size"]
                else:
                    pnl = (position["entry"] - exit_price) * position["size"]
                capital += pnl
                trades.append({
                    "entry_time": position["entry_time"],
                    "exit_time": row.name,
                    "side": position["side"],
                    "entry": position["entry"],
                    "exit": exit_price,
                    "pnl": pnl,
                    "pnl_pct": 100 * pnl / initial_capital,
                    "reason": exit_reason,
                    "bars": i - position["entry_idx"]
                })
                position = None

        # 2. Nuova entrata (solo se flat)
        if position is None and signal in ("COMPRA", "VENDI") and atr > 0:
            risk_amount = capital * (risk_pct / 100.0)
            sl_distance = cfg["sl_atr"] * atr
            if sl_distance <= 0:
                continue
            size = risk_amount / sl_distance  # unità

            if signal == "COMPRA":
                entry = close
                sl = entry - sl_distance
                tp = entry + cfg["tp_atr"] * atr
            else:
                entry = close
                sl = entry + sl_distance
                tp = entry - cfg["tp_atr"] * atr

            position = {
                "side": signal,
                "entry": entry,
                "sl": sl,
                "tp": tp,
                "size": size,
                "entry_idx": i,
                "entry_time": row.name
            }

        equity_curve.append(capital)

    # Chiudi eventuale posizione rimasta aperta all'ultimo prezzo
    if position is not None:
        last = df.iloc[-1]
        exit_price = last["Close"]
        if position["side"] == "COMPRA":
            pnl = (exit_price - position["entry"]) * position["size"]
        else:
            pnl = (position["entry"] - exit_price) * position["size"]
        capital += pnl
        trades.append({
            "entry_time": position["entry_time"],
            "exit_time": last.name,
            "side": position["side"],
            "entry": position["entry"],
            "exit": exit_price,
            "pnl": pnl,
            "pnl_pct": 100 * pnl / initial_capital,
            "reason": "Fine periodo",
            "bars": len(df) - 1 - position["entry_idx"]
        })
        equity_curve.append(capital)

    return trades, equity_curve, capital


def print_stats(trades, equity_curve, final_capital, initial_capital, mode):
    print("\n" + "=" * 70)
    print(f"  BACKTEST 2 ANNI  |  Modalità: {mode.upper()}")
    print(f"  {MODES[mode]['description']}")
    print("=" * 70)

    if not trades:
        print("  Nessun trade generato.")
        return

    df_t = pd.DataFrame(trades)
    wins = df_t[df_t["pnl"] > 0]
    losses = df_t[df_t["pnl"] <= 0]

    total_pnl = df_t["pnl"].sum()
    winrate = 100 * len(wins) / len(df_t)
    avg_win = wins["pnl"].mean() if len(wins) else 0
    avg_loss = losses["pnl"].mean() if len(losses) else 0
    profit_factor = abs(wins["pnl"].sum() / losses["pnl"].sum()) if len(losses) and losses["pnl"].sum() != 0 else float("inf")

    # Max drawdown
    eq = np.array(equity_curve)
    peak = np.maximum.accumulate(eq)
    dd = (eq - peak) / peak * 100
    max_dd = dd.min()

    # Per side
    long_trades = df_t[df_t["side"] == "COMPRA"]
    short_trades = df_t[df_t["side"] == "VENDI"]

    print(f"\nCAPITALE")
    print(f"  Iniziale     : {initial_capital:,.2f} $")
    print(f"  Finale       : {final_capital:,.2f} $")
    print(f"  Profitto     : {total_pnl:+,.2f} $  ({100*total_pnl/initial_capital:+.1f}%)")
    print(f"  Max Drawdown : {max_dd:.1f}%")

    print(f"\nTRADE")
    print(f"  Totale       : {len(df_t)}")
    print(f"  Long         : {len(long_trades)}  (PnL {long_trades['pnl'].sum():+,.2f} $)")
    print(f"  Short        : {len(short_trades)}  (PnL {short_trades['pnl'].sum():+,.2f} $)")
    print(f"  Winrate      : {winrate:.1f}%")
    print(f"  Profit Factor: {profit_factor:.2f}")
    print(f"  Media vincente: {avg_win:+,.2f} $")
    print(f"  Media perdente: {avg_loss:+,.2f} $")
    print(f"  Durata media : {df_t['bars'].mean():.1f} giorni")

    print(f"\nUSCITE")
    for reason, cnt in df_t["reason"].value_counts().items():
        print(f"  {reason:<18}: {cnt}")

    # Migliori / peggiori
    print(f"\nMIGLIORI 3 TRADE")
    for _, t in df_t.nlargest(3, "pnl").iterrows():
        print(f"  {t['side']:<7} {t['entry_time'].date()} → {t['exit_time'].date()}  PnL {t['pnl']:+.2f} $  ({t['reason']})")

    print(f"\nPEGGIORI 3 TRADE")
    for _, t in df_t.nsmallest(3, "pnl").iterrows():
        print(f"  {t['side']:<7} {t['entry_time'].date()} → {t['exit_time'].date()}  PnL {t['pnl']:+.2f} $  ({t['reason']})")

    print("=" * 70)


def main():
    initial_capital = 10000.0
    risk_pct = 1.0  # 1% di rischio per trade

    df = fetch_data()
    df = add_indicators(df)

    results = {}
    for mode in ["conservative", "balanced", "aggressive"]:
        trades, equity, final_cap = run_backtest(df.copy(), mode=mode,
                                                 initial_capital=initial_capital,
                                                 risk_pct=risk_pct)
        print_stats(trades, equity, final_cap, initial_capital, mode)
        results[mode] = {
            "trades": len(trades),
            "final": final_cap,
            "pnl_pct": 100 * (final_cap - initial_capital) / initial_capital,
            "winrate": 100 * sum(1 for t in trades if t["pnl"] > 0) / len(trades) if trades else 0
        }

    # Riepilogo finale
    print("\n" + "=" * 70)
    print("  RIEPILOGO CONFRONTO MODALITÀ (capitale iniziale 10.000 $)")
    print("=" * 70)
    print(f"  {'Modalità':<14} {'Trade':>6} {'Winrate':>8} {'Profitto':>10} {'Capitale finale':>16}")
    print("  " + "-" * 60)
    for mode, r in results.items():
        print(f"  {mode:<14} {r['trades']:>6} {r['winrate']:>7.1f}% {r['pnl_pct']:>+9.1f}% {r['final']:>15,.2f} $")
    print("=" * 70)
    print("\nNote importanti:")
    print("  • Backtest su dati daily (non 15m) per coprire 2 anni interi")
    print("  • Rischio fisso 1% del capitale per ogni trade")
    print("  • Non include spread, swap, slippage → risultati ottimistici")
    print("  • Passato ≠ futuro. Usa sempre risk management reale")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
