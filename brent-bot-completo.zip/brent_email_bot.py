#!/usr/bin/env python3
"""
Brent CFD Signal Bot + Notifiche EMAIL
--------------------------------------
Destinatario: lerbi.demoreti@hotmail.com

Funzionalità:
  - Segnali COMPRA / VENDI / NEUTRO
  - Modalità conservative / balanced / aggressive
  - Offset prezzo per allineare al tuo CFD
  - Loop continuo
  - Invio email automatico quando il segnale CAMBIA
  - Email di test all'avvio (opzionale)

CONFIGURAZIONE EMAIL (obbligatoria):
  1. Vai su https://account.microsoft.com/security
  2. Attiva "Verifica in due passaggi" se non attiva
  3. Crea una "Password per le app" (App password)
  4. Inserisci email e app-password qui sotto nella sezione CONFIG

Uso:
  python3 brent_email_bot.py
  python3 brent_email_bot.py --mode conservative --offset 3.35
  python3 brent_email_bot.py --test-email          # invia solo email di test
  python3 brent_email_bot.py --loop --interval 5   # loop ogni 5 minuti
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime
import ta
import argparse
import time
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import warnings
warnings.filterwarnings("ignore")

# ============================================================
# ==========  CONFIGURAZIONE EMAIL (MODIFICA QUI)  ==========
# ============================================================

EMAIL_MITTENTE = "lerbi.demoreti@hotmail.com"      # il tuo Hotmail
EMAIL_PASSWORD = "SOSTITUISCI_CON_APP_PASSWORD"    # <-- App Password (16 caratteri)
EMAIL_DESTINATARIO = "lerbi.demoreti@hotmail.com"  # dove ricevere le notifiche

SMTP_SERVER = "smtp-mail.outlook.com"
SMTP_PORT = 587

# ============================================================
# ==========  CONFIGURAZIONE TRADING  ========================
# ============================================================

SYMBOL = "BZ=F"
INTERVAL = "15m"
PERIOD = "10d"
PRICE_OFFSET = 3.35          # allinea ~103 futures → ~106.3 tuo CFD
MODE = "balanced"            # conservative | balanced | aggressive
LOOP_MINUTES = 5

EMA_FAST, EMA_SLOW = 20, 50
RSI_PERIOD, BB_PERIOD, ATR_PERIOD = 14, 20, 14

MODES = {
    "conservative": {
        "rsi_buy_max": 55, "rsi_sell_min": 45,
        "rsi_oversold": 25, "rsi_overbought": 75,
        "require_ema_cross": True,
        "sl_atr": 1.8, "tp_atr": 2.5,
        "description": "Pochi segnali, alta qualità"
    },
    "balanced": {
        "rsi_buy_max": 65, "rsi_sell_min": 35,
        "rsi_oversold": 30, "rsi_overbought": 70,
        "require_ema_cross": False,
        "sl_atr": 1.5, "tp_atr": 2.0,
        "description": "Equilibrio frequenza/qualità"
    },
    "aggressive": {
        "rsi_buy_max": 72, "rsi_sell_min": 28,
        "rsi_oversold": 35, "rsi_overbought": 65,
        "require_ema_cross": False,
        "sl_atr": 1.2, "tp_atr": 1.8,
        "description": "Più segnali, più rischio"
    }
}

# ============================================================
# ==========  FUNZIONI EMAIL  ================================
# ============================================================

def invia_email(oggetto, corpo_html, corpo_testo=None):
    """Invia email tramite Outlook/Hotmail SMTP"""
    if EMAIL_PASSWORD == "SOSTITUISCI_CON_APP_PASSWORD":
        print("⚠️  EMAIL NON CONFIGURATA: inserisci la App Password nel file.")
        print("   L'email NON è stata inviata.")
        return False

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = oggetto
        msg["From"] = EMAIL_MITTENTE
        msg["To"] = EMAIL_DESTINATARIO

        if corpo_testo is None:
            corpo_testo = "Segnale Brent CFD - apri l'email in formato HTML"

        msg.attach(MIMEText(corpo_testo, "plain"))
        msg.attach(MIMEText(corpo_html, "html"))

        context = ssl.create_default_context()
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.ehlo()
            server.starttls(context=context)
            server.ehlo()
            server.login(EMAIL_MITTENTE, EMAIL_PASSWORD)
            server.sendmail(EMAIL_MITTENTE, EMAIL_DESTINATARIO, msg.as_string())

        print(f"✅ Email inviata → {EMAIL_DESTINATARIO}")
        return True
    except Exception as e:
        print(f"❌ Errore invio email: {e}")
        return False


def crea_email_segnale(signal, reason, last, mode, offset):
    """Crea oggetto e corpo HTML dell'email di segnale"""
    colore = "#16a34a" if signal == "COMPRA" else "#dc2626" if signal == "VENDI" else "#ca8a04"
    emoji = "🟢" if signal == "COMPRA" else "🔴" if signal == "VENDI" else "🟡"

    oggetto = f"{emoji} BRENT {signal} | {last['Close']:.2f} $ | {datetime.now().strftime('%d/%m %H:%M')}"

    cfg = MODES[mode]
    atr = last["ATR"]

    if signal == "COMPRA":
        sl = last["Close"] - cfg["sl_atr"] * atr
        tp = last["Close"] + cfg["tp_atr"] * atr
        livelli = f"""
        <tr><td>Entry</td><td><b>~{last['Close']:.2f} $</b></td></tr>
        <tr><td>Stop Loss</td><td style="color:#dc2626">~{sl:.2f} $ (−{cfg['sl_atr']} ATR)</td></tr>
        <tr><td>Take Profit</td><td style="color:#16a34a">~{tp:.2f} $ (+{cfg['tp_atr']} ATR)</td></tr>
        """
    elif signal == "VENDI":
        sl = last["Close"] + cfg["sl_atr"] * atr
        tp = last["Close"] - cfg["tp_atr"] * atr
        livelli = f"""
        <tr><td>Entry</td><td><b>~{last['Close']:.2f} $</b></td></tr>
        <tr><td>Stop Loss</td><td style="color:#dc2626">~{sl:.2f} $ (+{cfg['sl_atr']} ATR)</td></tr>
        <tr><td>Take Profit</td><td style="color:#16a34a">~{tp:.2f} $ (−{cfg['tp_atr']} ATR)</td></tr>
        """
    else:
        livelli = "<tr><td colspan='2'>Nessun trade consigliato</td></tr>"

    html = f"""
    <html>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#0f172a; color:#e2e8f0; padding:20px;">
      <div style="max-width:480px; margin:0 auto; background:#1e293b; border-radius:12px; overflow:hidden; border:1px solid #334155;">
        <div style="background:{colore}; padding:16px 20px; text-align:center;">
          <h1 style="margin:0; color:white; font-size:22px;">{emoji} {signal}</h1>
          <p style="margin:4px 0 0; color:rgba(255,255,255,0.9); font-size:14px;">Brent CFD Signal Bot</p>
        </div>
        <div style="padding:20px;">
          <p style="margin:0 0 12px; font-size:15px;">{reason}</p>
          <table style="width:100%; border-collapse:collapse; font-size:14px;">
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">Prezzo</td><td style="padding:8px 0; text-align:right;"><b>{last['Close']:.2f} $</b></td></tr>
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">RSI (14)</td><td style="padding:8px 0; text-align:right;">{last['RSI']:.1f}</td></tr>
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">Trend</td><td style="padding:8px 0; text-align:right;">{last['Trend']}</td></tr>
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">EMA 20 / 50</td><td style="padding:8px 0; text-align:right;">{last['EMA_fast']:.2f} / {last['EMA_slow']:.2f}</td></tr>
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">ATR</td><td style="padding:8px 0; text-align:right;">{last['ATR']:.3f}</td></tr>
            <tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0; color:#94a3b8;">Modalità</td><td style="padding:8px 0; text-align:right;">{mode}</td></tr>
          </table>
          <h3 style="margin:20px 0 8px; font-size:14px; color:#94a3b8;">LIVELLI OPERATIVI</h3>
          <table style="width:100%; border-collapse:collapse; font-size:14px;">
            {livelli}
          </table>
          <p style="margin:20px 0 0; font-size:11px; color:#64748b; text-align:center;">
            {datetime.now().strftime('%d/%m/%Y %H:%M:%S')} · Offset {offset:+.2f} · Non è un consiglio finanziario
          </p>
        </div>
      </div>
    </body>
    </html>
    """

    testo = f"""
BRENT CFD SIGNAL BOT
====================
SEGNALE: {signal}
Motivo : {reason}
Prezzo : {last['Close']:.2f} $
RSI    : {last['RSI']:.1f}
Trend  : {last['Trend']}
Modalità: {mode}
Ora    : {datetime.now().strftime('%d/%m/%Y %H:%M')}
"""
    return oggetto, html, testo


def invia_email_test():
    """Invia un'email di prova per verificare la configurazione"""
    oggetto = "✅ Test Brent Signal Bot – configurazione OK"
    html = f"""
    <html><body style="font-family:sans-serif; background:#0f172a; color:#e2e8f0; padding:30px;">
      <div style="max-width:420px; margin:0 auto; background:#1e293b; border-radius:12px; padding:24px; border:1px solid #334155;">
        <h2 style="margin:0 0 12px; color:#22c55e;">✅ Email di test ricevuta</h2>
        <p>Il bot è configurato correttamente e può inviarti i segnali Brent.</p>
        <p style="font-size:13px; color:#94a3b8;">Destinatario: {EMAIL_DESTINATARIO}<br>
        Ora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
      </div>
    </body></html>
    """
    return invia_email(oggetto, html, "Test Brent Signal Bot – configurazione OK")

# ============================================================
# ==========  LOGICA TRADING  ================================
# ============================================================

def fetch_data():
    ticker = yf.Ticker(SYMBOL)
    df = ticker.history(period=PERIOD, interval=INTERVAL)
    if df.empty:
        raise ValueError("Nessun dato ricevuto da Yahoo Finance")
    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df.dropna(inplace=True)
    return df


def add_indicators(df):
    df["EMA_fast"] = ta.trend.ema_indicator(df["Close"], window=EMA_FAST)
    df["EMA_slow"] = ta.trend.ema_indicator(df["Close"], window=EMA_SLOW)
    df["RSI"] = ta.momentum.rsi(df["Close"], window=RSI_PERIOD)
    bb = ta.volatility.BollingerBands(df["Close"], window=BB_PERIOD, window_dev=2)
    df["BB_upper"] = bb.bollinger_hband()
    df["BB_lower"] = bb.bollinger_lband()
    df["ATR"] = ta.volatility.average_true_range(df["High"], df["Low"], df["Close"], window=ATR_PERIOD)
    df["Trend"] = np.where(
        (df["EMA_fast"] > df["EMA_slow"]) & (df["Close"] > df["EMA_fast"]), "BULLISH",
        np.where((df["EMA_fast"] < df["EMA_slow"]) & (df["Close"] < df["EMA_fast"]), "BEARISH", "SIDEWAYS")
    )
    return df


def apply_offset(df, offset):
    if offset == 0:
        return df
    for c in ["Open", "High", "Low", "Close", "EMA_fast", "EMA_slow", "BB_upper", "BB_lower"]:
        if c in df.columns:
            df[c] = df[c] + offset
    return df


def generate_signal(row, mode):
    cfg = MODES[mode]
    close, rsi = row["Close"], row["RSI"]
    ema_f, ema_s = row["EMA_fast"], row["EMA_slow"]
    bb_u, bb_l = row["BB_upper"], row["BB_lower"]
    trend = row["Trend"]

    buy = (trend == "BULLISH" and rsi < cfg["rsi_buy_max"] and rsi > 40 and close > ema_f)
    if cfg["require_ema_cross"]:
        buy = buy and (ema_f > ema_s)
    if buy:
        return "COMPRA", f"Trend rialzista + RSI {rsi:.1f} sano"

    sell = (trend == "BEARISH" and rsi > cfg["rsi_sell_min"] and rsi < 60 and close < ema_f)
    if cfg["require_ema_cross"]:
        sell = sell and (ema_f < ema_s)
    if sell:
        return "VENDI", f"Trend ribassista + RSI {rsi:.1f} sano"

    if rsi < cfg["rsi_oversold"] and close <= bb_l * 1.001:
        return "COMPRA", f"RSI oversold {rsi:.1f} + Bollinger inferiore"
    if rsi > cfg["rsi_overbought"] and close >= bb_u * 0.999:
        return "VENDI", f"RSI overbought {rsi:.1f} + Bollinger superiore"

    return "NEUTRO", "Nessuna condizione chiara – resta fuori"


def print_report(df, mode, offset):
    last = df.iloc[-1]
    signal, reason = generate_signal(last, mode)
    cfg = MODES[mode]

    GREEN, RED, YELLOW, CYAN, BOLD, RESET = "\033[92m", "\033[91m", "\033[93m", "\033[96m", "\033[1m", "\033[0m"
    color = GREEN if signal == "COMPRA" else RED if signal == "VENDI" else YELLOW

    print("\n" + "=" * 60)
    print(f"{BOLD}  BRENT EMAIL BOT  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}")
    print("=" * 60)
    print(f"  Modalità : {mode} | Offset : {offset:+.2f}")
    print(f"  Prezzo   : {last['Close']:.3f} $   RSI : {last['RSI']:.1f}   Trend : {last['Trend']}")
    print(f"  {color}{BOLD}>>>  {signal}  <<<{RESET}")
    print(f"  Motivo   : {reason}")
    print("=" * 60)
    return signal, reason, last


def save_log(signal, last, mode):
    with open("/home/workdir/artifacts/signal_log.txt", "a") as f:
        f.write(f"{datetime.now().isoformat()} | {signal:7s} | Close={last['Close']:.3f} | RSI={last['RSI']:.1f} | {mode}\n")


# ============================================================
# ==========  MAIN  ==========================================
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="Brent Signal Bot + Email")
    parser.add_argument("--mode", choices=["conservative", "balanced", "aggressive"], default=MODE)
    parser.add_argument("--offset", type=float, default=PRICE_OFFSET)
    parser.add_argument("--loop", action="store_true", help="Loop continuo")
    parser.add_argument("--interval", type=int, default=LOOP_MINUTES, help="Minuti tra controlli")
    parser.add_argument("--test-email", action="store_true", help="Invia solo email di test")
    parser.add_argument("--force-email", action="store_true", help="Invia email anche se segnale = NEUTRO")
    args = parser.parse_args()

    mode = args.mode
    offset = args.offset

    # --- Solo test email ---
    if args.test_email:
        print("Invio email di test...")
        ok = invia_email_test()
        if ok:
            print("Controlla la casella di posta (anche spam).")
        return

    print(f"Modalità: {mode.upper()} | Offset: {offset:+.2f} $")
    print("Scarico dati Brent...")

    try:
        df = fetch_data()
        df = add_indicators(df).dropna()
        df = apply_offset(df, offset)

        signal, reason, last = print_report(df, mode, offset)
        save_log(signal, last, mode)

        # Invia email al primo avvio se c'è un segnale operativo
        if signal != "NEUTRO" or args.force_email:
            oggetto, html, testo = crea_email_segnale(signal, reason, last, mode, offset)
            invia_email(oggetto, html, testo)
        else:
            print("Segnale NEUTRO → nessuna email inviata (usa --force-email per forzare)")

        if not args.loop:
            return

        # --- LOOP CONTINUO ---
        print(f"\n🔄 LOOP attivo – controllo ogni {args.interval} minuti")
        print("   Premi Ctrl+C per fermare\n")
        last_signal = signal

        while True:
            time.sleep(args.interval * 60)
            try:
                df = fetch_data()
                df = add_indicators(df).dropna()
                df = apply_offset(df, offset)
                signal, reason, last = print_report(df, mode, offset)
                save_log(signal, last, mode)

                # Invia email SOLO se il segnale è cambiato e non è NEUTRO
                if signal != last_signal:
                    if signal != "NEUTRO" or args.force_email:
                        print(f"🚨 Cambio segnale: {last_signal} → {signal} → invio email...")
                        oggetto, html, testo = crea_email_segnale(signal, reason, last, mode, offset)
                        invia_email(oggetto, html, testo)
                    else:
                        print(f"Segnale tornato a NEUTRO (da {last_signal}) – nessuna email")
                    last_signal = signal
                else:
                    print(f"Segnale invariato ({signal}) – nessuna email")

            except Exception as e:
                print(f"Errore nel loop: {e}")
                time.sleep(30)

    except Exception as e:
        print(f"Errore: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
