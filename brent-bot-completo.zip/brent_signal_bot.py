#!/usr/bin/env python3
"""
Brent CFD Signal Bot v2
-----------------------
Funzionalità:
  - Segnali COMPRA / VENDI / NEUTRO
  - Modalità CONSERVATIVE / BALANCED / AGGRESSIVE
  - Offset prezzo (per allineare futures ↔ tuo CFD)
  - Loop continuo (controlla ogni N minuti)
  - Backtest semplice sugli ultimi giorni
  - Log dei segnali

Uso:
  python3 brent_signal_bot.py                  # una volta
  python3 brent_signal_bot.py --loop           # loop continuo
  python3 brent_signal_bot.py --backtest       # backtest
  python3 brent_signal_bot.py --mode aggressive
  python3 brent_signal_bot.py --offset 3.3     # allinea al tuo CFD (~106)
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timezone
import ta
import argparse
import time
import warnings
warnings.filterwarnings("ignore")

# ============== CONFIGURAZIONE DEFAULT ==============
SYMBOL = "BZ=F"
INTERVAL = "15m"
PERIOD = "15d"
RSI_PERIOD = 14
EMA_FAST = 20
EMA_SLOW = 50
BB_PERIOD = 20
ATR_PERIOD = 14

# Offset per allineare il prezzo del futures al tuo CFD
# Esempio: se futures = 103 e sul tuo broker vedi 106.3 → offset ≈ 3.3
PRICE_OFFSET = 0.0

# Modalità: conservative | balanced | aggressive
MODE = "balanced"

# Loop
LOOP_MINUTES = 5

# ============== REGOLE PER MODALITÀ ==============
MODES = {
    "conservative": {
        "rsi_buy_max": 55,
        "rsi_sell_min": 45,
        "rsi_oversold": 25,
        "rsi_overbought": 75,
        "require_ema_cross": True,      # prezzo deve essere chiaramente sopra/sotto entrambe le EMA
        "min_atr_mult": 1.8,            # stop più largo
        "tp_atr_mult": 2.5,
        "description": "Pochi segnali, alta qualità, stop più larghi"
    },
    "balanced": {
        "rsi_buy_max": 65,
        "rsi_sell_min": 35,
        "rsi_oversold": 30,
        "rsi_overbought": 70,
        "require_ema_cross": False,
        "min_atr_mult": 1.5,
        "tp_atr_mult": 2.0,
        "description": "Equilibrio tra frequenza e qualità"
    },
    "aggressive": {
        "rsi_buy_max": 72,
        "rsi_sell_min": 28,
        "rsi_oversold": 35,
        "rsi_overbought": 65,
        "require_ema_cross": False,
        "min_atr_mult": 1.2,
        "tp_atr_mult": 1.8,
        "description": "Più segnali, stop più stretti, più rischio"
    }
}

# ============== FUNZIONI CORE ==============

def fetch_data(symbol=SYMBOL, period=PERIOD, interval=INTERVAL):
    ticker = yf.Ticker(symbol)
    df = ticker.history(period=period, interval=interval)
    if df.empty:
        raise ValueError(f"Nessun dato per {symbol}")
    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df.dropna(inplace=True)
    return df


def add_indicators(df):
    df["EMA_fast"] = ta.trend.ema_indicator(df["Close"], window=EMA_FAST)
    df["EMA_slow"] = ta.trend.ema_indicator(df["Close"], window=EMA_SLOW)
    df["RSI"] = ta.momentum.rsi(df["Close"], window=RSI_PERIOD)

    bb = ta.volatility.BollingerBands(df["Close"], window=BB_PERIOD, window_dev=2)
    df["BB_upper"] = bb.bollinger_hband()
    df["BB_mid"] = bb.bollinger_mavg()
    df["BB_lower"] = bb.bollinger_lband()

    df["ATR"] = ta.volatility.average_true_range(
        df["High"], df["Low"], df["Close"], window=ATR_PERIOD
    )

    df["Trend"] = np.where(
        (df["EMA_fast"] > df["EMA_slow"]) & (df["Close"] > df["EMA_fast"]),
        "BULLISH",
        np.where(
            (df["EMA_fast"] < df["EMA_slow"]) & (df["Close"] < df["EMA_fast"]),
            "BEARISH",
            "SIDEWAYS"
        )
    )
    return df


def generate_signal(row, mode="balanced"):
    """Genera segnale in base alla modalità scelta"""
    cfg = MODES[mode]
    close = row["Close"]
    rsi = row["RSI"]
    ema_f = row["EMA_fast"]
    ema_s = row["EMA_slow"]
    bb_u = row["BB_upper"]
    bb_l = row["BB_lower"]
    trend = row["Trend"]

    # --- COMPRA ---
    buy_cond = (
        trend == "BULLISH"
        and rsi < cfg["rsi_buy_max"]
        and rsi > 40
        and close > ema_f
    )
    if cfg["require_ema_cross"]:
        buy_cond = buy_cond and (ema_f > ema_s)

    if buy_cond:
        return "COMPRA", f"Trend rialzista + RSI {rsi:.1f} sano ({mode})"

    # --- VENDI ---
    sell_cond = (
        trend == "BEARISH"
        and rsi > cfg["rsi_sell_min"]
        and rsi < 60
        and close < ema_f
    )
    if cfg["require_ema_cross"]:
        sell_cond = sell_cond and (ema_f < ema_s)

    if sell_cond:
        return "VENDI", f"Trend ribassista + RSI {rsi:.1f} sano ({mode})"

    # --- Mean reversion estremi ---
    if rsi < cfg["rsi_oversold"] and close <= bb_l * 1.001:
        return "COMPRA", f"RSI oversold {rsi:.1f} + banda inferiore Bollinger ({mode})"

    if rsi > cfg["rsi_overbought"] and close >= bb_u * 0.999:
        return "VENDI", f"RSI overbought {rsi:.1f} + banda superiore Bollinger ({mode})"

    return "NEUTRO", f"Nessuna condizione chiara – resta fuori ({mode})"


def apply_offset(df, offset):
    """Applica offset al prezzo per allineare al CFD del broker"""
    if offset == 0:
        return df
    cols = ["Open", "High", "Low", "Close", "EMA_fast", "EMA_slow", "BB_upper", "BB_mid", "BB_lower"]
    for c in cols:
        if c in df.columns:
            df[c] = df[c] + offset
    return df


def print_report(df, mode="balanced", offset=0.0):
    last = df.iloc[-1]
    prev = df.iloc[-2] if len(df) > 1 else last
    signal, reason = generate_signal(last, mode)
    cfg = MODES[mode]

    GREEN, RED, YELLOW, CYAN, BOLD, RESET = (
        "\033[92m", "\033[91m", "\033[93m", "\033[96m", "\033[1m", "\033[0m"
    )
    color = GREEN if signal == "COMPRA" else RED if signal == "VENDI" else YELLOW

    print("\n" + "=" * 62)
    print(f"{BOLD}  BRENT CFD SIGNAL BOT v2  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}")
    print("=" * 62)

    print(f"\n{CYAN}CONFIGURAZIONE{RESET}")
    print(f"  Modalità   : {mode.upper()} → {cfg['description']}")
    print(f"  Offset     : {offset:+.2f} $  (futures + offset = tuo CFD)")
    print(f"  Timeframe  : {INTERVAL}")

    print(f"\n{CYAN}PREZZO{RESET}")
    print(f"  Close      : {last['Close']:.3f} $")
    print(f"  Variazione : {last['Close'] - prev['Close']:+.3f} $")
    print(f"  High / Low : {last['High']:.3f} / {last['Low']:.3f}")

    print(f"\n{CYAN}INDICATORI{RESET}")
    print(f"  EMA {EMA_FAST}/{EMA_SLOW}  : {last['EMA_fast']:.3f} / {last['EMA_slow']:.3f}")
    print(f"  RSI (14)   : {last['RSI']:.1f}")
    print(f"  BB Upper   : {last['BB_upper']:.3f}")
    print(f"  BB Lower   : {last['BB_lower']:.3f}")
    print(f"  ATR (14)   : {last['ATR']:.3f}")
    print(f"  Trend      : {last['Trend']}")

    print(f"\n{BOLD}SEGNALE ATTUALE{RESET}")
    print(f"  {color}{BOLD}>>>  {signal}  <<<{RESET}")
    print(f"  Motivo     : {reason}")

    atr = last["ATR"]
    print(f"\n{CYAN}LIVELLI OPERATIVI (indicativi){RESET}")
    if signal == "COMPRA":
        sl = last["Close"] - cfg["min_atr_mult"] * atr
        tp = last["Close"] + cfg["tp_atr_mult"] * atr
        print(f"  Entry      : ~{last['Close']:.2f}")
        print(f"  Stop Loss  : ~{sl:.2f}  (−{cfg['min_atr_mult']} ATR)")
        print(f"  Take Profit: ~{tp:.2f}  (+{cfg['tp_atr_mult']} ATR)")
        print(f"  Rischio/Rendimento ≈ 1 : {cfg['tp_atr_mult']/cfg['min_atr_mult']:.1f}")
    elif signal == "VENDI":
        sl = last["Close"] + cfg["min_atr_mult"] * atr
        tp = last["Close"] - cfg["tp_atr_mult"] * atr
        print(f"  Entry      : ~{last['Close']:.2f}")
        print(f"  Stop Loss  : ~{sl:.2f}  (+{cfg['min_atr_mult']} ATR)")
        print(f"  Take Profit: ~{tp:.2f}  (−{cfg['tp_atr_mult']} ATR)")
        print(f"  Rischio/Rendimento ≈ 1 : {cfg['tp_atr_mult']/cfg['min_atr_mult']:.1f}")
    else:
        print("  Nessun trade consigliato in questo momento.")
        print(f"  Range ATR attuale : ±{atr:.2f} $")

    # Ultimi segnali
    print(f"\n{CYAN}ULTIMI 6 SEGNALI{RESET}")
    print(f"  {'Data/Ora':<20} {'Close':>8} {'RSI':>6} {'Trend':<9} {'Segnale'}")
    print("  " + "-" * 52)
    for i in range(-6, 0):
        row = df.iloc[i]
        sig, _ = generate_signal(row, mode)
        ts = row.name.strftime("%m-%d %H:%M") if hasattr(row.name, "strftime") else str(row.name)[:16]
        print(f"  {ts:<20} {row['Close']:>8.2f} {row['RSI']:>6.1f} {row['Trend']:<9} {sig}")

    print("\n" + "=" * 62)
    print("Questo è un bot di SEGNALI, non un esecutore automatico.")
    print("Usa sempre stop loss. Non è un consiglio finanziario.")
    print("=" * 62 + "\n")

    return signal, reason, last


def run_backtest(df, mode="balanced"):
    """Backtest semplice: conta segnali e performance grezza"""
    print("\n" + "=" * 62)
    print(f"  BACKTEST  |  Modalità: {mode.upper()}")
    print("=" * 62)

    signals = []
    for i in range(len(df)):
        row = df.iloc[i]
        sig, reason = generate_signal(row, mode)
        signals.append({
            "time": row.name,
            "close": row["Close"],
            "rsi": row["RSI"],
            "trend": row["Trend"],
            "signal": sig
        })

    sig_df = pd.DataFrame(signals)

    # Conta segnali
    counts = sig_df["signal"].value_counts()
    print(f"\nDistribuzione segnali (ultime {len(df)} candele):")
    for s in ["COMPRA", "VENDI", "NEUTRO"]:
        cnt = counts.get(s, 0)
        pct = 100 * cnt / len(sig_df)
        print(f"  {s:<8} : {cnt:4d}  ({pct:5.1f}%)")

    # Simulazione grezza: quando c’è un segnale, guarda il movimento delle prossime 4 candele (1h)
    print("\nPerformance grezza (movimento medio nelle 4 candele successive = ~1 ora):")
    results = {"COMPRA": [], "VENDI": []}
    for i in range(len(sig_df) - 4):
        sig = sig_df.iloc[i]["signal"]
        if sig not in ["COMPRA", "VENDI"]:
            continue
        entry = sig_df.iloc[i]["close"]
        future = sig_df.iloc[i+4]["close"]
        move = future - entry
        if sig == "VENDI":
            move = -move   # per short il profitto è quando scende
        results[sig].append(move)

    for side in ["COMPRA", "VENDI"]:
        moves = results[side]
        if moves:
            avg = np.mean(moves)
            winrate = 100 * sum(1 for m in moves if m > 0) / len(moves)
            print(f"  {side:<8} : media {avg:+.3f} $  |  winrate {winrate:.1f}%  |  trade {len(moves)}")
        else:
            print(f"  {side:<8} : nessun trade nel periodo")

    print("\nNota: backtest grezzo, senza costi di spread/commissioni e senza gestione posizione.")
    print("=" * 62 + "\n")


def save_log(signal, last, mode, offset):
    with open("/home/workdir/artifacts/signal_log.txt", "a") as f:
        f.write(
            f"{datetime.now().isoformat()} | {signal:7s} | "
            f"Close={last['Close']:.3f} | RSI={last['RSI']:.1f} | "
            f"Mode={mode} | Offset={offset:+.2f}\n"
        )


def main():
    parser = argparse.ArgumentParser(description="Brent CFD Signal Bot v2")
    parser.add_argument("--mode", choices=["conservative", "balanced", "aggressive"],
                        default=MODE, help="Modalità di trading")
    parser.add_argument("--offset", type=float, default=PRICE_OFFSET,
                        help="Offset prezzo (es. 3.3 se il tuo CFD è ~3.3$ più alto)")
    parser.add_argument("--loop", action="store_true", help="Esegui in loop continuo")
    parser.add_argument("--interval", type=int, default=LOOP_MINUTES,
                        help="Minuti tra un controllo e l'altro (default 5)")
    parser.add_argument("--backtest", action="store_true", help="Esegui solo backtest")
    args = parser.parse_args()

    mode = args.mode
    offset = args.offset

    print(f"Modalità: {mode.upper()} | Offset: {offset:+.2f} $")
    print("Scarico dati Brent (BZ=F)...")

    try:
        df = fetch_data()
        df = add_indicators(df)
        df = df.dropna()
        df = apply_offset(df, offset)

        if args.backtest:
            run_backtest(df, mode)
            return

        signal, reason, last = print_report(df, mode, offset)
        save_log(signal, last, mode, offset)
        print("Log aggiornato → signal_log.txt")

        if args.loop:
            print(f"\n🔄 Modalità LOOP attiva – controllo ogni {args.interval} minuti")
            print("Premi Ctrl+C per fermare\n")
            last_signal = signal
            while True:
                time.sleep(args.interval * 60)
                try:
                    df = fetch_data()
                    df = add_indicators(df)
                    df = df.dropna()
                    df = apply_offset(df, offset)
                    signal, reason, last = print_report(df, mode, offset)
                    save_log(signal, last, mode, offset)

                    if signal != last_signal and signal != "NEUTRO":
                        print(f"\n🚨 CAMBIO SEGNALE: {last_signal} → {signal} 🚨\n")
                    last_signal = signal
                except Exception as e:
                    print(f"Errore nel loop: {e}")
                    time.sleep(30)

    except Exception as e:
        print(f"Errore: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
